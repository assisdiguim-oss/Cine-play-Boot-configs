package com.willbootjb.tvbox

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val preferredPackage = "com.unitv.free"
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    private fun showAppPickerByNameAndIcon(infoTextView: TextView) {
        val allApps = UnitvRootLocator.getAllApps(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 24, 32, 24)
            setBackgroundColor(0xFF111520.toInt())
        }

        val searchBox = EditText(this).apply {
            hint = "Digite o nome do app (ex: UniTV Free)"
            setText("UniTV")
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF94A3B8.toInt())
        }
        val listLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val scroll = ScrollView(this).apply {
            addView(listLayout)
        }

        container.addView(searchBox)
        container.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            620
        ))

        val dialog = AlertDialog.Builder(this)
            .setTitle("Selecionar UniTV (Sistema/Raiz ou Usuario)")
            .setView(container)
            .setNegativeButton("Fechar", null)
            .create()

        fun renderFiltered(query: String) {
            listLayout.removeAllViews()
            val q = query.trim().lowercase()
            val filtered = if (q.isEmpty()) allApps else allApps.filter {
                it.label.lowercase().contains(q) || it.packageName.lowercase().contains(q)
            }
            val itemsToShow = if (filtered.isEmpty()) allApps else filtered

            itemsToShow.forEach { app ->
                val originTag = if (app.isSystemOrRootApp) "Raiz/Sistema" else "App Usuario"
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(16, 18, 16, 18)
                    isFocusable = true
                    setOnClickListener {
                        getSharedPreferences("willbootjb_prefs", MODE_PRIVATE)
                            .edit()
                            .putString("selected_unitv_package", app.packageName)
                            .putString("selected_unitv_label", app.label)
                            .apply()
                        infoTextView.text = "App selecionado: ${app.label} (${app.packageName}) [$originTag] — pronto!"
                        android.widget.Toast.makeText(
                            this@MainActivity,
                            "Vinculado direto: ${app.label} ($originTag)",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                        dialog.dismiss()
                    }
                }
                val iconView = ImageView(this).apply {
                    setImageDrawable(app.icon)
                }
                val textView = TextView(this).apply {
                    text = "${app.label} [$originTag]\n${app.packageName} · ${app.apkSourceDir}"
                    setTextColor(0xFFE2E8F0.toInt())
                    textSize = 12f
                    setPadding(24, 0, 0, 0)
                }
                row.addView(iconView, LinearLayout.LayoutParams(84, 84))
                row.addView(textView)
                listLayout.addView(row)
            }
        }

        renderFiltered("UniTV")
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderFiltered(s?.toString() ?: "")
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        dialog.show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val detectedApp = UnitvRootLocator.findBestUnitv(this, preferredPackage)
        val systemRootHints = UnitvRootLocator.scanSystemRootApkHints()
        val initialNet = NetworkMonitor.getCurrentState(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 40, 48, 40)
            setBackgroundColor(0xFF090B10.toInt())
        }

        val title = TextView(this).apply {
            text = "WillbootJB Independente - TV Box & Smartphone (Android 7 ao 10)"
            textSize = 21f
            setTextColor(0xFFFBBF24.toInt())
        }

        val netBanner = TextView(this).apply {
            text = "Conexao de Rede: ${initialNet.transportLabel} · Execucao 100% independente na TV Box"
            textSize = 13f
            setTextColor(if (initialNet.connected) 0xFF34D399.toInt() else 0xFFF87171.toInt())
            setPadding(0, 8, 0, 8)
        }

        val prefs = getSharedPreferences("willbootjb_prefs", MODE_PRIVATE)
        val savedFolderUri = prefs.getString("backup_tree_uri", null)

        val info = TextView(this).apply {
            val appDesc = detectedApp?.let {
                "${it.label} (${it.packageName}) [${if (it.isSystemOrRootApp) "Raiz/Sistema" else "Usuario"}]"
            } ?: if (systemRootHints.isNotEmpty()) {
                "APK na raiz: ${systemRootHints.first()}"
            } else {
                "Nao localizado (use o botao 5)"
            }
            text = "Operador: Renato acessórios | MAC Inicial: 9C:00:D3:B6:C5:C8\nUniTV encontrado: $appDesc\nPasta de memoria: /Documents/WillbootJB/ (gravacao imediata)${if (savedFolderUri != null) "\nPasta SAF: $savedFolderUri" else ""}"
            textSize = 13f
            setTextColor(0xFFE2E8F0.toInt())
            setPadding(0, 8, 0, 20)
        }

        networkCallback = NetworkMonitor.watchNetwork(this) { state ->
            runOnUiThread {
                netBanner.text = "Conexao de Rede: ${state.transportLabel} · Execucao 100% independente na TV Box"
                netBanner.setTextColor(if (state.connected) 0xFF34D399.toInt() else 0xFFF87171.toInt())
            }
        }

        val btnStartMonitor = Button(this).apply {
            text = "1. Iniciar Monitor Flutuante Independente"
            isFocusable = true
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, MonitorOverlayService::class.java))
                }
            }
        }

        val btnOpenUnitv = Button(this).apply {
            text = "2. Abrir UniTV (Raiz/Sistema ou Usuario) & Testar Canais"
            isFocusable = true
            setOnClickListener {
                val targetApp = UnitvRootLocator.findBestUnitv(this@MainActivity, preferredPackage)
                if (targetApp != null && UnitvRootLocator.launchDirect(this@MainActivity, targetApp)) {
                    BootAccessibilityService.instance?.setAutoCaptureEnabled(true)
                    BootAccessibilityService.instance?.openChannelsTabForTest()
                } else {
                    android.widget.Toast.makeText(
                        this@MainActivity,
                        "UniTV nao aberto automaticamente. Selecione o app pela lista (raiz/sistema ou usuario).",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                    showAppPickerByNameAndIcon(info)
                }
            }
        }

        val btnAccessibility = Button(this).apply {
            text = "3. Ativar Acessibilidade (Leitura de Tela & Cliques)"
            isFocusable = true
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val btnPickFolder = Button(this).apply {
            text = "4. Escolher Pasta na Memoria do Aparelho (Zero Perda)"
            isFocusable = true
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                    addFlags(
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    )
                }
                startActivityForResult(intent, 202)
            }
        }

        val btnFindAppByNameIcon = Button(this).apply {
            text = "5. Buscar UniTV na Raiz / Sistema ou por Ícone"
            isFocusable = true
            setOnClickListener {
                showAppPickerByNameAndIcon(info)
            }
        }

        root.addView(title)
        root.addView(netBanner)
        root.addView(info)
        root.addView(btnStartMonitor)
        root.addView(btnOpenUnitv)
        root.addView(btnAccessibility)
        root.addView(btnPickFolder)
        root.addView(btnFindAppByNameIcon)
        setContentView(root)

        requestStorageIfNeeded()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            networkCallback?.let {
                val cm = getSystemService(CONNECTIVITY_SERVICE) as? ConnectivityManager
                try { cm?.unregisterNetworkCallback(it) } catch (_: Exception) {}
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 202 && resultCode == RESULT_OK) {
            data?.data?.let { treeUri ->
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                try {
                    contentResolver.takePersistableUriPermission(treeUri, flags)
                } catch (_: Exception) {}
                getSharedPreferences("willbootjb_prefs", MODE_PRIVATE)
                    .edit()
                    .putString("backup_tree_uri", treeUri.toString())
                    .apply()
                android.widget.Toast.makeText(
                    this,
                    "Pasta na memoria do smartphone vinculada com sucesso!",
                    android.widget.Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun requestStorageIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE),
                101
            )
        }
    }
}
