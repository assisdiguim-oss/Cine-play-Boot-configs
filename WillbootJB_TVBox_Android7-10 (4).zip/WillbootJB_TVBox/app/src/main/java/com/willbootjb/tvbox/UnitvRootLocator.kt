package com.willbootjb.tvbox

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import java.io.File

data class LocatedUnitvApp(
    val label: String,
    val packageName: String,
    val icon: Drawable,
    val isSystemOrRootApp: Boolean,
    val apkSourceDir: String,
    val launchIntent: Intent?
)

object UnitvRootLocator {
    private val knownPackages = listOf(
        "com.unitv.free",
        "com.unitv.tv",
        "com.unitv.app",
        "com.unitv.pro",
        "com.tv.unitv",
        "com.uni.tv"
    )

    private val systemRootDirs = listOf(
        "/system/app",
        "/system/priv-app",
        "/vendor/app",
        "/product/app"
    )

    fun scanSystemRootApkHints(): List<String> {
        val found = mutableListOf<String>()
        for (dirPath in systemRootDirs) {
            val dir = File(dirPath)
            if (!dir.exists() || !dir.isDirectory) continue
            dir.listFiles()?.forEach { child ->
                if (child.name.contains("unitv", ignoreCase = true) ||
                    child.name.contains("uni_tv", ignoreCase = true)
                ) {
                    found.add(child.absolutePath)
                }
            }
        }
        return found
    }

    fun getAllApps(context: Context): List<LocatedUnitvApp> {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val launcherMatches = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
        val byPackage = linkedMapOf<String, LocatedUnitvApp>()

        for (ri in launcherMatches) {
            val pkg = ri.activityInfo.packageName
            val appInfo = ri.activityInfo.applicationInfo
            val isSystem = (appInfo.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
            val launch = pm.getLaunchIntentForPackage(pkg) ?: Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
                component = ComponentName(pkg, ri.activityInfo.name)
            }
            byPackage[pkg] = LocatedUnitvApp(
                label = ri.loadLabel(pm)?.toString() ?: pkg,
                packageName = pkg,
                icon = ri.loadIcon(pm),
                isSystemOrRootApp = isSystem,
                apkSourceDir = appInfo.sourceDir ?: "",
                launchIntent = launch
            )
        }

        // Tambem inspeciona apps instalados na particao raiz/sistema sem icone padrao no launcher
        val installedApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        for (appInfo in installedApps) {
            if (byPackage.containsKey(appInfo.packageName)) continue
            val label = pm.getApplicationLabel(appInfo)?.toString() ?: appInfo.packageName
            val isUnitvLike = label.contains("unitv", ignoreCase = true) ||
                appInfo.packageName.contains("unitv", ignoreCase = true) ||
                knownPackages.contains(appInfo.packageName)
            if (!isUnitvLike) continue

            val isSystem = (appInfo.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0 ||
                (appInfo.sourceDir?.startsWith("/system") == true)
            val launch = pm.getLaunchIntentForPackage(appInfo.packageName)
            byPackage[appInfo.packageName] = LocatedUnitvApp(
                label = label,
                packageName = appInfo.packageName,
                icon = pm.getApplicationIcon(appInfo),
                isSystemOrRootApp = isSystem,
                apkSourceDir = appInfo.sourceDir ?: "",
                launchIntent = launch
            )
        }

        return byPackage.values.sortedWith(
            compareByDescending<LocatedUnitvApp> {
                it.label.contains("unitv", ignoreCase = true) || it.packageName.contains("unitv", ignoreCase = true)
            }.thenByDescending { it.isSystemOrRootApp }
             .thenBy { it.label.lowercase() }
        )
    }

    fun findBestUnitv(context: Context, preferredPkg: String): LocatedUnitvApp? {
        val prefs = context.getSharedPreferences("willbootjb_prefs", Context.MODE_PRIVATE)
        val savedPkg = prefs.getString("selected_unitv_package", null)
        val apps = getAllApps(context)

        if (!savedPkg.isNullOrBlank()) {
            apps.firstOrNull { it.packageName == savedPkg }?.let { return it }
        }
        apps.firstOrNull { it.packageName == preferredPkg }?.let { return it }
        apps.firstOrNull {
            it.label.equals("UniTV Free", ignoreCase = true) ||
                it.label.contains("unitv free", ignoreCase = true) ||
                it.label.contains("unitv", ignoreCase = true)
        }?.let { return it }

        for (pkg in knownPackages) {
            apps.firstOrNull { it.packageName == pkg }?.let { return it }
        }
        return null
    }

    fun launchDirect(context: Context, app: LocatedUnitvApp): Boolean {
        val intent = app.launchIntent ?: context.packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            context.startActivity(intent)
            return true
        }
        return false
    }
}
