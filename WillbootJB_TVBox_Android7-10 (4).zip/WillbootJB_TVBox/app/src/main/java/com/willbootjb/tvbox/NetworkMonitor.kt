package com.willbootjb.tvbox

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Build

data class NetworkState(
    val connected: Boolean,
    val transportLabel: String
)

object NetworkMonitor {
    fun getCurrentState(context: Context): NetworkState {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return NetworkState(false, "Sem rede")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val activeNetwork = cm.activeNetwork ?: return NetworkState(false, "Desconectado")
            val caps = cm.getNetworkCapabilities(activeNetwork) ?: return NetworkState(false, "Sem sinal")
            val hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            if (!hasInternet) return NetworkState(false, "Sem acesso a internet")

            val type = when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Cabo Ethernet Online"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi Online"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Dados Moveis Online"
                else -> "Rede Online"
            }
            return NetworkState(true, type)
        }

        @Suppress("DEPRECATION")
        val info = cm.activeNetworkInfo
        @Suppress("DEPRECATION")
        return if (info != null && info.isConnected) {
            NetworkState(true, "${info.typeName} Online")
        } else {
            NetworkState(false, "Desconectado")
        }
    }

    fun watchNetwork(context: Context, onChanged: (NetworkState) -> Unit): ConnectivityManager.NetworkCallback? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return null
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return null
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                onChanged(getCurrentState(context))
            }
            override fun onLost(network: Network) {
                onChanged(getCurrentState(context))
            }
        }
        cm.registerDefaultNetworkCallback(callback)
        return callback
    }
}
