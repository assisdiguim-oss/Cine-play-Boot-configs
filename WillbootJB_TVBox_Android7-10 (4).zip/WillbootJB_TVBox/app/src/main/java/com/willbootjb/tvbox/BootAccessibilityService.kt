package com.willbootjb.tvbox

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class BootAccessibilityService : AccessibilityService() {

    companion object {
        var instance: BootAccessibilityService? = null
    }

    private var autoCaptureEnabled = false
    private var lastCapturedPin: String? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val pinRegex = Regex("""\b(\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4})\b""")
    private val daysRegex = Regex("""(\d{1,4})\s*(dias|days)""", RegexOption.IGNORE_CASE)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    fun setAutoCaptureEnabled(enabled: Boolean) {
        autoCaptureEnabled = enabled
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!autoCaptureEnabled) return
        val pkg = event?.packageName?.toString() ?: return
        if (!pkg.contains("unitv", ignoreCase = true)) return

        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()
        collectTexts(root, texts)
        val joined = texts.joinToString(" | ")

        val pinMatch = pinRegex.find(joined)?.groupValues?.getOrNull(1)?.replace(" ", "-")
        val daysMatch = daysRegex.find(joined)?.groupValues?.getOrNull(1)?.toIntOrNull()

        if (pinMatch != null && pinMatch != lastCapturedPin) {
            lastCapturedPin = pinMatch
            val activeDays = daysMatch ?: 0
            val macFallback = "9C:00:D3:B6:C5:C8"
            ConfigBatchManager.registerGoodConfig(
                GoodConfigRecord(
                    mac = macFallback,
                    accountId = "AUTO-TVBOX",
                    days = activeDays,
                    pin16 = pinMatch,
                    xmlContent = "<map><string name=\"pin_code\">$pinMatch</string><int name=\"active_days\" value=\"$activeDays\" /></map>"
                )
            )
        }
    }

    private fun collectTexts(node: AccessibilityNodeInfo?, out: MutableList<String>) {
        if (node == null) return
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        for (i in 0 until node.childCount) {
            collectTexts(node.getChild(i), out)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacksAndMessages(null)
        instance = null
    }

    /**
     * Android 7.0+ (API 24+) suporta dispatchGesture nativo para clicar (780, 360) e (1169, 44).
     */
    fun clickAt(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    /**
     * Abre a aba de TV / Lista de Canais no UniTV instalado na TV Box e seleciona o primeiro canal ao vivo.
     */
    fun openChannelsTabForTest() {
        mainHandler.postDelayed({ clickAt(780f, 360f) }, 1600L) // Avanca intro se houver
        mainHandler.postDelayed({ clickAt(140f, 118f) }, 3000L) // Aba TV
        mainHandler.postDelayed({ clickAt(260f, 240f) }, 4200L) // Canal 1 da lista
    }
}
