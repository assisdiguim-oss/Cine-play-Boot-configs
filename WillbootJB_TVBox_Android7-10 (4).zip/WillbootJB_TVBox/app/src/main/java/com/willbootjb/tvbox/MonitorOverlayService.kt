package com.willbootjb.tvbox

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MonitorOverlayService : Service() {
    private var windowManager: WindowManager? = null
    private var overlayView: LinearLayout? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private var isRunning = false
    private var statusView: TextView? = null
    private var netView: TextView? = null
    private var batchView: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        // Android 8.0+ usa TYPE_APPLICATION_OVERLAY; Android 7.0/7.1 usa TYPE_PHONE
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 32
        }

        overlayView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#EC070A12"))
            setPadding(24, 18, 24, 18)

            addView(TextView(context).apply {
                text = "WillbootJB - Monitor Independente"
                setTextColor(Color.parseColor("#FBBF24"))
                textSize = 14f
            })

            netView = TextView(context).apply {
                val net = NetworkMonitor.getCurrentState(this@MonitorOverlayService)
                text = "Rede: ${net.transportLabel}"
                setTextColor(if (net.connected) Color.parseColor("#34D399") else Color.parseColor("#F87171"))
                textSize = 11f
            }
            addView(netView)

            addView(TextView(context).apply {
                text = "MAC Base: 9C:00:D3:B6:C5:C8 | Op: Renato acessórios"
                setTextColor(Color.parseColor("#FACC15"))
                textSize = 11f
            })

            batchView = TextView(context).apply {
                text = "Lote atual: ${ConfigBatchManager.getCurrentBatchCount()}/10 · Lote #${ConfigBatchManager.getNextBatchNumber()}"
                setTextColor(Color.WHITE)
                textSize = 11f
            }
            addView(batchView)

            statusView = TextView(context).apply {
                text = "Status: Pronto na TV Box"
                setTextColor(Color.parseColor("#93C5FD"))
                textSize = 11f
                setPadding(0, 4, 0, 10)
            }
            addView(statusView)

            val btnRow = LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
            }

            val btnOpen = Button(context).apply {
                text = "Abrir UniTV"
                textSize = 11f
                setOnClickListener {
                    val found = UnitvRootLocator.findBestUnitv(this@MonitorOverlayService, "com.unitv.free")
                    if (found != null && UnitvRootLocator.launchDirect(this@MonitorOverlayService, found)) {
                        statusView?.text = "UniTV aberto (${if (found.isSystemOrRootApp) "Raiz/Sistema" else "Usuario"})"
                        BootAccessibilityService.instance?.openChannelsTabForTest()
                    } else {
                        statusView?.text = "UniTV nao localizado"
                    }
                }
            }

            val btnToggle = Button(context).apply {
                text = "Iniciar"
                textSize = 11f
                setOnClickListener {
                    isRunning = !isRunning
                    text = if (isRunning) "Pausar" else "Iniciar"
                    statusView?.text = if (isRunning) "Monitorando tela UniTV..." else "Pausado"
                    BootAccessibilityService.instance?.setAutoCaptureEnabled(isRunning)
                }
            }

            val btnClose = Button(context).apply {
                text = "X"
                textSize = 11f
                setOnClickListener { stopSelf() }
            }

            btnRow.addView(btnOpen)
            btnRow.addView(btnToggle)
            btnRow.addView(btnClose)
            addView(btnRow)
        }

        windowManager?.addView(overlayView, params)
        scheduleStatusRefresh()
    }

    private fun scheduleStatusRefresh() {
        uiHandler.postDelayed(object : Runnable {
            override fun run() {
                if (overlayView == null) return
                val net = NetworkMonitor.getCurrentState(this@MonitorOverlayService)
                netView?.text = "Rede: ${net.transportLabel}"
                netView?.setTextColor(if (net.connected) Color.parseColor("#34D399") else Color.parseColor("#F87171"))
                batchView?.text = "Lote atual: ${ConfigBatchManager.getCurrentBatchCount()}/10 · Lote #${ConfigBatchManager.getNextBatchNumber()}"
                uiHandler.postDelayed(this, 3000L)
            }
        }, 3000L)
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacksAndMessages(null)
        overlayView?.let { windowManager?.removeView(it) }
        overlayView = null
    }
}
