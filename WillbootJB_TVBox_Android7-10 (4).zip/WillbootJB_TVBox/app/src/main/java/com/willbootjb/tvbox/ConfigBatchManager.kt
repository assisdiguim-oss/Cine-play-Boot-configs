package com.willbootjb.tvbox

import android.os.Environment
import org.json.JSONObject
import java.io.File

data class GoodConfigRecord(
    val mac: String,
    val accountId: String,
    val days: Int,
    val pin16: String?,
    val xmlContent: String
)

object ConfigBatchManager {
    private const val BATCH_SIZE = 10
    private val currentBatch = mutableListOf<GoodConfigRecord>()
    private var batchIndex = 1

    private val knownPinRegistry = mutableMapOf<String, String>()

    private fun getRootWillbootDir(): File {
        val docs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        val primary = File(docs, "WillbootJB")
        if (primary.exists() || primary.mkdirs()) return primary
        val fallback = File(Environment.getExternalStorageDirectory(), "WillbootJB")
        if (!fallback.exists()) fallback.mkdirs()
        return fallback
    }

    fun getBaseDir(): File {
        val dir = File(getRootWillbootDir(), "configs_boas")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun getAllConfigsDir(): File {
        val dir = File(getRootWillbootDir(), "todas_configs")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun getAvailablePinsDir(): File {
        val dir = File(getRootWillbootDir(), "pins_disponiveis")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun getLinkedPinsDir(): File {
        val dir = File(getRootWillbootDir(), "pins_outros_receptores")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun getRegistryFile(): File = File(getRootWillbootDir(), "known_pins_registry.txt")
    private fun getMasterJournalFile(): File = File(getRootWillbootDir(), "configs_master_journal.jsonl")
    private fun getPendingBufferFile(): File = File(getRootWillbootDir(), "pending_batch_buffer.jsonl")

    private fun loadRegistryIfEmpty() {
        if (knownPinRegistry.isNotEmpty()) return
        val file = getRegistryFile()
        if (!file.exists()) return
        file.readLines().forEach { line ->
            val parts = line.split("|")
            if (parts.size >= 2) {
                knownPinRegistry[parts[0]] = parts[1]
            }
        }
    }

    private fun persistPinLink(pin: String, mac: String) {
        knownPinRegistry[pin] = mac
        getRegistryFile().appendText("$pin|$mac\n")
    }

    /**
     * Salva imediatamente cada config na memoria do smartphone (todas_configs/ e configs_master_journal.jsonl)
     * para nunca perder informacao, separa PINs disponiveis de PINs ja vinculados em outros receptores,
     * e a cada 10 configs boas grava a pasta Lote_XX_10configs.
     */
    fun registerGoodConfig(record: GoodConfigRecord): File? {
        loadRegistryIfEmpty()

        val compactMac = record.mac.replace(":", "")
        val pin = record.pin16?.takeIf { it.isNotBlank() }
        val existingMac = if (pin != null) knownPinRegistry[pin] else null
        val alreadyLinkedElsewhere = existingMac != null && !existingMac.equals(record.mac, ignoreCase = true)

        // 1. Gravacao imediata na pasta todas_configs/ + journal JSONL (zero perda mesmo se desligar o aparelho)
        val singleJson = JSONObject().apply {
            put("mac", record.mac)
            put("accountId", record.accountId)
            put("activeDays", record.days)
            put("pin16", pin ?: JSONObject.NULL)
            put("pinStatus", when {
                pin == null -> JSONObject.NULL
                alreadyLinkedElsewhere -> "vinculado_outro_receptor"
                else -> "disponivel"
            })
            put("linkedReceptorMac", if (alreadyLinkedElsewhere) existingMac else JSONObject.NULL)
            put("savedAt", System.currentTimeMillis())
        }
        File(getAllConfigsDir(), "${compactMac}.config").writeText(singleJson.toString(2))
        File(getAllConfigsDir(), "${compactMac}_config.xml").writeText(record.xmlContent)
        getMasterJournalFile().appendText(singleJson.toString() + "\n")

        val isGood = record.days > 0 || pin != null
        if (!isGood) return null

        if (pin != null) {
            val cleanPin = pin.replace("-", "")
            if (alreadyLinkedElsewhere) {
                val linkedFile = File(getLinkedPinsDir(), "${compactMac}_PIN_VINCULADO_$cleanPin.config")
                linkedFile.writeText(
                    "STATUS=JA_SALVO_OUTRO_RECEPTOR\nMAC_ATUAL=${record.mac}\nRECEPTOR_ORIGINAL=$existingMac\nPIN=$pin\nDIAS=${record.days}\n"
                )
            } else {
                if (existingMac == null) persistPinLink(pin, record.mac)
                val availFile = File(getAvailablePinsDir(), "${compactMac}_PIN_DISPONIVEL_$cleanPin.config")
                availFile.writeText(
                    "STATUS=PIN_DISPONIVEL_SEM_VINCULO\nMAC=${record.mac}\nPIN=$pin\nDIAS=${record.days}\n"
                )
            }
        }

        currentBatch.add(record)
        getPendingBufferFile().appendText(singleJson.toString() + "\n")

        if (currentBatch.size >= BATCH_SIZE) {
            val folderName = "Lote_%02d_10configs".format(batchIndex)
            val batchDir = File(getBaseDir(), folderName)
            val availDir = File(batchDir, "PINS_DISPONIVEIS").apply { mkdirs() }
            val linkedDir = File(batchDir, "PINS_JA_VINCULADOS").apply { mkdirs() }

            val availSummary = StringBuilder()
            val linkedSummary = StringBuilder()

            currentBatch.forEach { item ->
                val compactMac = item.mac.replace(":", "")
                val itemPin = item.pin16?.takeIf { it.isNotBlank() }
                val firstMac = if (itemPin != null) knownPinRegistry[itemPin] else null
                val isRepeat = firstMac != null && !firstMac.equals(item.mac, ignoreCase = true)

                val targetDir = when {
                    itemPin == null -> batchDir
                    isRepeat -> linkedDir
                    else -> availDir
                }

                val pinSuffix = when {
                    itemPin == null -> ""
                    isRepeat -> "_PIN_VINCULADO_${itemPin.replace("-", "")}"
                    else -> "_PIN_DISPONIVEL_${itemPin.replace("-", "")}"
                }

                val cfgFile = File(targetDir, "$compactMac$pinSuffix.config")
                val json = JSONObject().apply {
                    put("mac", item.mac)
                    put("accountId", item.accountId)
                    put("activeDays", item.days)
                    put("pin16", itemPin ?: JSONObject.NULL)
                    put("pinStatus", when {
                        itemPin == null -> JSONObject.NULL
                        isRepeat -> "vinculado_outro_receptor"
                        else -> "disponivel"
                    })
                    put("linkedReceptorMac", if (isRepeat) firstMac else JSONObject.NULL)
                    put("savedAt", System.currentTimeMillis())
                }
                cfgFile.writeText(json.toString(2))

                val xmlFile = File(targetDir, "${compactMac}_config.xml")
                xmlFile.writeText(item.xmlContent)

                if (itemPin != null) {
                    if (isRepeat) {
                        linkedSummary.append("MAC Atual: ${item.mac} | Receptor Original: $firstMac | Dias: ${item.days} | PIN: $itemPin\n")
                    } else {
                        availSummary.append("MAC: ${item.mac} | Dias: ${item.days} | PIN Disponivel: $itemPin\n")
                    }
                }
            }

            if (availSummary.isNotEmpty()) {
                File(availDir, "PINS_DISPONIVEIS_SEM_VINCULO.txt").writeText(availSummary.toString())
            }
            if (linkedSummary.isNotEmpty()) {
                File(linkedDir, "PINS_JA_VINCULADOS_OUTROS_RECEPTORES.txt").writeText(linkedSummary.toString())
            }

            currentBatch.clear()
            getPendingBufferFile().writeText("")
            batchIndex += 1
            return batchDir
        }
        return null
    }

    fun getCurrentBatchCount(): Int = currentBatch.size
    fun getNextBatchNumber(): Int = batchIndex
}
